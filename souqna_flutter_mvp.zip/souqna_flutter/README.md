# سوقنا – Souqna (نسخة أولية)

تطبيق سوق محلي يبدأ من كركوك. هذه حزمة بداية برمجية (Starter MVP)، وليست تطبيقاً منشوراً أو جاهزاً للإنتاج بعد.

## الموجود حالياً
- تسجيل حساب بالبريد وكلمة المرور.
- اختيار نوع الحساب: مشتري أو تاجر.
- حفظ ملف المستخدم في Firestore.
- عرض المنتجات المنشورة في كركوك.
- إضافة منتج إلى قاعدة البيانات.
- زر تواصل/طلب عبر WhatsApp.
- قواعد Firestore أولية.

## المتطلبات
- Flutter SDK
- Android Studio أو VS Code
- حساب Google/Firebase
- هاتف Android أو محاكي

## تشغيل المشروع
1. فك ضغط الملف.
2. افتح مجلد `souqna_flutter` في VS Code أو Android Studio.
3. نفّذ:
   ```bash
   flutter pub get
   ```
4. أنشئ مشروع Firebase من Firebase Console.
5. فعّل Authentication > Email/Password.
6. أنشئ Cloud Firestore وفعّل Storage عند الحاجة.
7. ثبّت FlutterFire CLI ثم نفّذ:
   ```bash
   dart pub global activate flutterfire_cli
   flutterfire configure
   ```
   سيُنشئ هذا الملف `lib/firebase_options.dart` تلقائياً.
8. عدّل `lib/main.dart` ليستخدم إعدادات FlutterFire:
   ```dart
   import 'firebase_options.dart';
   await Firebase.initializeApp(
     options: DefaultFirebaseOptions.currentPlatform,
   );
   ```
   (استبدل `await Firebase.initializeApp();` الموجود حالياً.)
9. انشر قواعد `firestore.rules` من Firebase Console.
10. شغّل:
   ```bash
   flutter run
   ```

## شكل قاعدة البيانات المقترح

### users/{uid}
- name: string
- phone: string
- email: string
- role: `buyer` أو `seller`
- city: `كركوك`
- createdAt: timestamp

### products/{productId}
- sellerId: string
- sellerName: string
- title: string
- description: string
- priceIqd: number
- category: string
- imageUrl: string
- city: `كركوك`
- whatsapp: string
- active: boolean
- createdAt: timestamp

### orders/{orderId} (المرحلة التالية)
- buyerId: string
- sellerId: string
- productIds: array
- items: array of {productId, title, quantity, unitPriceIqd}
- fulfillment: `pickup` أو `delivery`
- status: `new`, `accepted`, `completed`, `cancelled`
- buyerPhone: string
- createdAt: timestamp

## ملاحظات مهمة قبل الإطلاق
- زر واتساب حالياً يفتح محادثة برسالة جاهزة؛ لا ينشئ طلباً محفوظاً في قاعدة البيانات بعد.
- حقل صورة المنتج غير مكتمل في واجهة الإضافة؛ نضيف رفع الصور في الخطوة التالية.
- يجب إضافة تحقق أقوى من أرقام الهاتف والأسعار والصلاحيات، ومنع التاجر من تغيير `sellerId` أو بياناته الحساسة.
- لا تستخدم قواعد تجريبية أو بيانات حقيقية قبل مراجعة الأمان.
- قبل النشر نضيف سياسة خصوصية، شروط استخدام، مراجعة المحتوى، وآلية للإبلاغ عن المنتجات والمحلات.
- لا توجد مدفوعات إلكترونية في هذه النسخة.
