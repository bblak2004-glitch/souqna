class Product {
  final String id;
  final String sellerId;
  final String sellerName;
  final String title;
  final String description;
  final int priceIqd;
  final String category;
  final String imageUrl;
  final String city;
  final String whatsapp;
  final bool active;

  const Product({
    required this.id,
    required this.sellerId,
    required this.sellerName,
    required this.title,
    required this.description,
    required this.priceIqd,
    required this.category,
    required this.imageUrl,
    required this.city,
    required this.whatsapp,
    required this.active,
  });

  factory Product.fromMap(String id, Map<String, dynamic> map) => Product(
    id: id,
    sellerId: map['sellerId'] ?? '',
    sellerName: map['sellerName'] ?? '',
    title: map['title'] ?? '',
    description: map['description'] ?? '',
    priceIqd: (map['priceIqd'] as num? ?? 0).toInt(),
    category: map['category'] ?? 'أخرى',
    imageUrl: map['imageUrl'] ?? '',
    city: map['city'] ?? 'كركوك',
    whatsapp: map['whatsapp'] ?? '',
    active: map['active'] ?? true,
  );

  Map<String, dynamic> toMap() => {
    'sellerId': sellerId,
    'sellerName': sellerName,
    'title': title,
    'description': description,
    'priceIqd': priceIqd,
    'category': category,
    'imageUrl': imageUrl,
    'city': city,
    'whatsapp': whatsapp,
    'active': active,
    'createdAt': DateTime.now().toUtc().toIso8601String(),
  };
}
