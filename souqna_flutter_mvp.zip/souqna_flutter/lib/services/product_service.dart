import 'package:cloud_firestore/cloud_firestore.dart';
import '../models/product.dart';

class ProductService {
  final _db = FirebaseFirestore.instance;

  Stream<List<Product>> watchProducts() {
    return _db.collection('products')
      .where('active', isEqualTo: true)
      .where('city', isEqualTo: 'كركوك')
      .snapshots()
      .map((snapshot) => snapshot.docs
        .map((doc) => Product.fromMap(doc.id, doc.data())).toList());
  }

  Future<void> addProduct(Product product) async {
    await _db.collection('products').add(product.toMap());
  }
}
