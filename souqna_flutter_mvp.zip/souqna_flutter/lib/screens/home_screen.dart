import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models/product.dart';
import '../services/auth_service.dart';
import '../services/product_service.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('سوقنا', style: TextStyle(fontWeight: FontWeight.bold)),
          actions: [
            IconButton(tooltip: 'تسجيل الخروج', onPressed: AuthService.instance.logout,
              icon: const Icon(Icons.logout)),
          ],
        ),
        body: Column(children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'ابحث عن منتج أو محل...',
                prefixIcon: const Icon(Icons.search),
                filled: true, fillColor: Colors.white,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
              ),
            ),
          ),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 16),
            child: Align(alignment: Alignment.centerRight,
              child: Text('أحدث المنتجات في كركوك', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold))),
          ),
          Expanded(
            child: StreamBuilder<List<Product>>(
              stream: ProductService().watchProducts(),
              builder: (context, snapshot) {
                if (snapshot.hasError) return const Center(child: Text('حدث خطأ في تحميل المنتجات'));
                if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
                final products = snapshot.data!;
                if (products.isEmpty) return const Center(
                  child: Text('ماكو منتجات حالياً\\nقريباً راح تظهر منتجات محلات كركوك',
                    textAlign: TextAlign.center));
                return GridView.builder(
                  padding: const EdgeInsets.all(12),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2, childAspectRatio: .68, crossAxisSpacing: 12, mainAxisSpacing: 12),
                  itemCount: products.length,
                  itemBuilder: (context, i) => ProductCard(product: products[i]),
                );
              },
            ),
          ),
        ]),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () => _showAddProduct(context),
          icon: const Icon(Icons.add),
          label: const Text('أضف منتجاً'),
        ),
      ),
    );
  }

  Future<void> _showAddProduct(BuildContext context) async {
    final user = AuthService.instance.currentUser;
    if (user == null) return;
    final title = TextEditingController();
    final price = TextEditingController();
    final whatsapp = TextEditingController();
    final description = TextEditingController();
    final category = TextEditingController(text: 'أخرى');
    await showDialog(context: context, builder: (dialogContext) => AlertDialog(
      title: const Text('إضافة منتج'),
      content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        _input(title, 'اسم المنتج'),
        _input(price, 'السعر بالدينار'),
        _input(category, 'القسم'),
        _input(description, 'الوصف'),
        _input(whatsapp, 'رقم واتساب مع رمز الدولة'),
      ])),
      actions: [
        TextButton(onPressed: () => Navigator.pop(dialogContext), child: const Text('إلغاء')),
        FilledButton(onPressed: () async {
          final amount = int.tryParse(price.text.trim());
          if (title.text.trim().isEmpty || amount == null || amount <= 0 || whatsapp.text.trim().isEmpty) return;
          final userDoc = await FirebaseFirestore.instance.collection('users').doc(user.uid).get();
          final data = userDoc.data() ?? {};
          await ProductService().addProduct(Product(
            id: '', sellerId: user.uid, sellerName: data['name'] ?? 'تاجر سوقنا',
            title: title.text.trim(), description: description.text.trim(),
            priceIqd: amount, category: category.text.trim(),
            imageUrl: '', city: 'كركوك', whatsapp: whatsapp.text.trim(), active: true,
          ));
          if (dialogContext.mounted) Navigator.pop(dialogContext);
        }, child: const Text('نشر المنتج')),
      ],
    ));
  }

  Widget _input(TextEditingController c, String label) => Padding(
    padding: const EdgeInsets.only(bottom: 8),
    child: TextField(controller: c, decoration: InputDecoration(labelText: label, border: const OutlineInputBorder())),
  );
}

class ProductCard extends StatelessWidget {
  final Product product;
  const ProductCard({super.key, required this.product});

  Future<void> _order(BuildContext context) async {
    final phone = product.whatsapp.replaceAll(RegExp(r'[^0-9]'), '');
    final message = Uri.encodeComponent('مرحباً، أريد الاستفسار عن ${product.title} بسعر ${product.priceIqd} دينار من تطبيق سوقنا.');
    final uri = Uri.parse('https://wa.me/$phone?text=$message');
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication) && context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تعذر فتح واتساب')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        Expanded(child: product.imageUrl.isEmpty
          ? const ColoredBox(color: Color(0xFFEDE7F6), child: Icon(Icons.shopping_bag_outlined, size: 54, color: Color(0xFF5525B8)))
          : Image.network(product.imageUrl, fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => const Icon(Icons.image_not_supported))),
        Padding(padding: const EdgeInsets.all(10), child: Column(
          crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(product.title, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.bold)),
            Text('${product.priceIqd} د.ع', style: const TextStyle(color: Color(0xFF5525B8), fontWeight: FontWeight.bold)),
            Text(product.sellerName, maxLines: 1, overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 12, color: Colors.black54)),
            const SizedBox(height: 6),
            SizedBox(width: double.infinity, child: FilledButton.tonal(
              onPressed: () => _order(context), child: const Text('اطلب عبر واتساب'))),
          ],
        )),
      ]),
    );
  }
}
