import 'package:flutter/material.dart';
import '../services/auth_service.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  final _form = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _email = TextEditingController();
  final _password = TextEditingController();
  bool _register = false;
  bool _busy = false;
  String _role = 'buyer';

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    setState(() => _busy = true);
    try {
      if (_register) {
        await AuthService.instance.register(
          name: _name.text, phone: _phone.text, email: _email.text,
          password: _password.text, role: _role,
        );
      } else {
        await AuthService.instance.login(_email.text, _password.text);
      }
    } on Exception catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('تعذر إكمال العملية: $e')));
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  void dispose() {
    _name.dispose(); _phone.dispose(); _email.dispose(); _password.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(child: Center(child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Form(key: _form, child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Icon(Icons.shopping_bag_rounded, size: 76, color: Color(0xFF5525B8)),
            const SizedBox(height: 8),
            const Text('سوقنا', textAlign: TextAlign.center,
              style: TextStyle(fontSize: 34, fontWeight: FontWeight.bold, color: Color(0xFF5525B8))),
            const Text('تسوّق من محلات كركوك', textAlign: TextAlign.center),
            const SizedBox(height: 28),
            if (_register) ...[
              _field(_name, 'الاسم الكامل'),
              _field(_phone, 'رقم الهاتف / واتساب'),
              DropdownButtonFormField<String>(
                value: _role,
                decoration: const InputDecoration(labelText: 'نوع الحساب', border: OutlineInputBorder()),
                items: const [
                  DropdownMenuItem(value: 'buyer', child: Text('مشتري')),
                  DropdownMenuItem(value: 'seller', child: Text('تاجر')),
                ],
                onChanged: (v) => setState(() => _role = v ?? 'buyer'),
              ),
              const SizedBox(height: 12),
            ],
            _field(_email, 'البريد الإلكتروني', keyboard: TextInputType.emailAddress),
            _field(_password, 'كلمة المرور', obscure: true),
            const SizedBox(height: 12),
            FilledButton(
              onPressed: _busy ? null : _submit,
              child: Text(_busy ? 'يرجى الانتظار...' : (_register ? 'إنشاء حساب' : 'تسجيل الدخول')),
            ),
            TextButton(
              onPressed: () => setState(() => _register = !_register),
              child: Text(_register ? 'لديك حساب؟ تسجيل الدخول' : 'مستخدم جديد؟ إنشاء حساب'),
            ),
          ],
        )),
      ))),
    );
  }

  Widget _field(TextEditingController c, String label,
      {bool obscure = false, TextInputType keyboard = TextInputType.text}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: TextFormField(
        controller: c, obscureText: obscure, keyboardType: keyboard,
        decoration: InputDecoration(labelText: label, border: const OutlineInputBorder()),
        validator: (v) => (v == null || v.trim().isEmpty) ? 'هذا الحقل مطلوب' : null,
      ),
    );
  }
}
